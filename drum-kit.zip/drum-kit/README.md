# DRUM KIT

A Pen created on CodePen.io. Original URL: [https://codepen.io/Alvis-X/pen/JjpgeqG](https://codepen.io/Alvis-X/pen/JjpgeqG).

